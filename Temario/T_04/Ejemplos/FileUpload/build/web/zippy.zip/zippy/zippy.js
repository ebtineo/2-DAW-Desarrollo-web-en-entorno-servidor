jQuery(function($) {
    $('#wp-admin-bar-zippy')
        .find('a')
        .addClass('thickbox')
        .attr('title', 'Zippy');
});